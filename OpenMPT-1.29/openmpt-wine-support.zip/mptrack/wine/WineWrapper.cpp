
#if defined(MPT_BUILD_WINESUPPORT_WRAPPER)

#include "WineWrapper.c"

#endif // MPT_BUILD_WINESUPPORT_WRAPPER
